export enum OS {
  WINDOWS = 'windows',
  MAC = 'mac',
  LINUX64 = 'linux64',
  LINUX32 = 'linux32',
  STANDALONE = 'standalone'
}
