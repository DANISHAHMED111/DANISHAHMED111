module.exports = {
  enableJSClass: false,
  enableClasses: false,
  minify: true,
  'feature-detects': ['css/flexbox', 'css/flexwrap', 'storage/localstorage']
};
