'use strict';
require('isomorphic-fetch');

jest.mock('@ledgerhq/hw-transport-u2f');
