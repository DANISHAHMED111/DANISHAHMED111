const svgMock = ({ src, ...props }) => <svg {...props} id={src} />;

export default svgMock;
