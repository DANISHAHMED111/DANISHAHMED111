import { Panel as UIPanel } from '@mycrypto/ui';
import styled from 'styled-components';

export const Panel = styled(UIPanel)`
  border-radius: 3px;
`;
