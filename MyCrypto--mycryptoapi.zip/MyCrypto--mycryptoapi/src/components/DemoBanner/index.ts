export { DemoGatewayBanner } from './DemoGatewayBanner';
